"use client"

import { useState } from "react"
import { AlertTriangle, Check, Pencil, TrendingUp } from "lucide-react"
import { AppShell } from "@/components/app-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useFinance } from "@/lib/finance-context"
import { formatCurrency } from "@/lib/format"
import { cn } from "@/lib/utils"
import type { Budget } from "@/lib/types"

export default function OrcamentoPage() {
  const { budgets, updateBudget, transactions, addTransaction, accounts, categories } = useFinance()
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null)
  const [newLimit, setNewLimit] = useState("")
  const [exceedConfirmation, setExceedConfirmation] = useState<{
    budget: Budget
    amount: number
    description: string
  } | null>(null)
  const [spendDialogOpen, setSpendDialogOpen] = useState(false)
  const [spendData, setSpendData] = useState({
    budgetId: "",
    amount: "",
    description: "",
  })

  const totalBudget = budgets.reduce((sum, b) => sum + b.limit, 0)
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0)
  const totalRemaining = totalBudget - totalSpent
  const overallProgress = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0

  const handleEditLimit = (budget: Budget) => {
    setEditingBudget(budget)
    setNewLimit(budget.limit.toString())
  }

  const handleSaveLimit = () => {
    if (editingBudget) {
      updateBudget(editingBudget.id, { limit: parseFloat(newLimit) || 0 })
      setEditingBudget(null)
      setNewLimit("")
    }
  }

  const handleSpendSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const budget = budgets.find((b) => b.id === spendData.budgetId)
    if (!budget) return

    const amount = parseFloat(spendData.amount) || 0
    const newSpent = budget.spent + amount

    // Check if this exceeds the limit
    if (newSpent > budget.limit) {
      setExceedConfirmation({
        budget,
        amount,
        description: spendData.description,
      })
      return
    }

    // Add the expense
    confirmSpend(budget, amount, spendData.description)
  }

  const confirmSpend = (budget: Budget, amount: number, description: string) => {
    // Update budget spent
    updateBudget(budget.id, { spent: budget.spent + amount })
    
    // Add transaction
    addTransaction({
      id: Date.now().toString(),
      description: description || budget.category,
      amount,
      type: "expense",
      category: budget.category,
      accountId: accounts[0]?.id || "",
      date: new Date().toISOString().split("T")[0],
      isPaid: true,
    })

    setSpendDialogOpen(false)
    setSpendData({ budgetId: "", amount: "", description: "" })
    setExceedConfirmation(null)
  }

  const handleExceedConfirm = () => {
    if (exceedConfirmation) {
      confirmSpend(
        exceedConfirmation.budget,
        exceedConfirmation.amount,
        exceedConfirmation.description
      )
    }
  }

  const BudgetCard = ({ budget }: { budget: Budget }) => {
    const progress = budget.limit > 0 ? (budget.spent / budget.limit) * 100 : 0
    const remaining = budget.limit - budget.spent
    const isOver = progress >= 100
    const isWarning = progress >= 80 && progress < 100

    return (
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div
                className="h-3 w-3 rounded-full"
                style={{ backgroundColor: budget.color }}
              />
              <span className="font-medium text-foreground">{budget.category}</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => handleEditLimit(budget)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline justify-between">
              <span className={cn(
                "text-2xl font-bold",
                isOver ? "text-destructive" : "text-foreground"
              )}>
                {formatCurrency(budget.spent)}
              </span>
              <span className="text-sm text-muted-foreground">
                de {formatCurrency(budget.limit)}
              </span>
            </div>

            <Progress 
              value={Math.min(progress, 100)} 
              className={cn(
                "h-2",
                isOver && "[&>div]:bg-destructive",
                isWarning && "[&>div]:bg-warning"
              )}
            />

            <div className="flex items-center justify-between text-sm">
              <span className={cn(
                isOver ? "text-destructive" : "text-muted-foreground"
              )}>
                {isOver ? (
                  <span className="flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    Excedido em {formatCurrency(Math.abs(remaining))}
                  </span>
                ) : (
                  `Restam ${formatCurrency(remaining)}`
                )}
              </span>
              <span className="text-muted-foreground">
                {progress.toFixed(0)}%
              </span>
            </div>
          </div>

          <Button
            variant="outline"
            size="sm"
            className="mt-3 w-full"
            onClick={() => {
              setSpendData({ ...spendData, budgetId: budget.id })
              setSpendDialogOpen(true)
            }}
          >
            Registrar gasto
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <AppShell title="Orçamento">
      <div className="space-y-6">
        {/* Overview card */}
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Orçamento mensal</p>
                <p className="text-3xl font-bold text-foreground">{formatCurrency(totalBudget)}</p>
              </div>
              <div className="flex gap-6">
                <div>
                  <p className="text-sm text-muted-foreground">Gasto</p>
                  <p className="text-xl font-semibold text-foreground">{formatCurrency(totalSpent)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Disponível</p>
                  <p className={cn(
                    "text-xl font-semibold",
                    totalRemaining < 0 ? "text-destructive" : "text-success"
                  )}>
                    {formatCurrency(totalRemaining)}
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <Progress 
                value={Math.min(overallProgress, 100)} 
                className={cn(
                  "h-3",
                  overallProgress >= 100 && "[&>div]:bg-destructive",
                  overallProgress >= 80 && overallProgress < 100 && "[&>div]:bg-warning"
                )}
              />
              <p className="mt-2 text-sm text-muted-foreground">
                {overallProgress.toFixed(0)}% do orçamento utilizado
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Budget categories */}
        <div>
          <h2 className="mb-4 text-lg font-semibold text-foreground">Categorias</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {budgets.map((budget) => (
              <BudgetCard key={budget.id} budget={budget} />
            ))}
          </div>
        </div>

        {/* Edit limit dialog */}
        <Dialog open={!!editingBudget} onOpenChange={(open) => !open && setEditingBudget(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar limite</DialogTitle>
              <DialogDescription>
                Defina o novo limite para {editingBudget?.category}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Novo limite</label>
                <Input
                  type="number"
                  step="0.01"
                  value={newLimit}
                  onChange={(e) => setNewLimit(e.target.value)}
                  placeholder="0,00"
                />
              </div>
              <Button onClick={handleSaveLimit} className="w-full">
                Salvar
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Add expense dialog */}
        <Dialog open={spendDialogOpen} onOpenChange={setSpendDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar gasto</DialogTitle>
              <DialogDescription>
                Adicione um novo gasto para {budgets.find((b) => b.id === spendData.budgetId)?.category}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSpendSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Descrição</label>
                <Input
                  placeholder="Ex: Supermercado..."
                  value={spendData.description}
                  onChange={(e) => setSpendData({ ...spendData, description: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Valor</label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0,00"
                  value={spendData.amount}
                  onChange={(e) => setSpendData({ ...spendData, amount: e.target.value })}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Adicionar gasto
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Exceed limit confirmation */}
        <AlertDialog open={!!exceedConfirmation} onOpenChange={(open) => !open && setExceedConfirmation(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                Limite excedido
              </AlertDialogTitle>
              <AlertDialogDescription>
                Este gasto de <strong>{formatCurrency(exceedConfirmation?.amount || 0)}</strong> irá 
                exceder o limite de <strong>{exceedConfirmation?.budget.category}</strong>.
                <br /><br />
                Novo total: <strong>{formatCurrency((exceedConfirmation?.budget.spent || 0) + (exceedConfirmation?.amount || 0))}</strong> de {formatCurrency(exceedConfirmation?.budget.limit || 0)}
                <br /><br />
                Deseja continuar mesmo assim?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleExceedConfirm}>
                Confirmar gasto
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AppShell>
  )
}
