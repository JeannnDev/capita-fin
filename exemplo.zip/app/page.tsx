"use client"

import { AppShell } from "@/components/app-shell"
import { BalanceCard } from "@/components/dashboard/balance-card"
import { AccountsOverview } from "@/components/dashboard/accounts-overview"
import { ExpenseChart } from "@/components/dashboard/expense-chart"
import { MonthlyChart } from "@/components/dashboard/monthly-chart"
import { UpcomingPayments } from "@/components/dashboard/upcoming-payments"
import { RecentTransactions } from "@/components/dashboard/recent-transactions"

export default function DashboardPage() {
  return (
    <AppShell title="Dashboard">
      <div className="space-y-6">
        {/* Balance card - full width on mobile */}
        <BalanceCard />

        {/* Main grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Charts section */}
          <div className="space-y-6 lg:col-span-2">
            <MonthlyChart />
            <div className="grid gap-6 sm:grid-cols-2">
              <ExpenseChart />
              <AccountsOverview />
            </div>
          </div>

          {/* Sidebar section */}
          <div className="space-y-6">
            <UpcomingPayments />
            <RecentTransactions />
          </div>
        </div>
      </div>
    </AppShell>
  )
}
