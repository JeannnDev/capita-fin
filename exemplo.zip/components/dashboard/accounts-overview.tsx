"use client"

import { Wallet, Building2, CreditCard, UtensilsCrossed, MoreHorizontal } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useFinance } from "@/lib/finance-context"
import { formatCurrency } from "@/lib/format"

const accountIcons: Record<string, typeof Wallet> = {
  wallet: Wallet,
  checking: Building2,
  savings: Building2,
  credit: CreditCard,
  food: UtensilsCrossed,
}

export function AccountsOverview() {
  const { accounts } = useFinance()

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-semibold">Contas</CardTitle>
        <Button variant="ghost" size="sm" className="text-sm text-muted-foreground">
          Ver todas
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {accounts.map((account) => {
          const Icon = accountIcons[account.type] || Wallet
          return (
            <div
              key={account.id}
              className="flex items-center justify-between rounded-lg p-2 transition-colors hover:bg-muted/50"
            >
              <div className="flex items-center gap-3">
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-full"
                  style={{ backgroundColor: `${account.color}20` }}
                >
                  <Icon className="h-5 w-5" style={{ color: account.color }} />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{account.name}</p>
                  <p className="text-xs text-muted-foreground">{account.institution}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-foreground">
                  {formatCurrency(account.balance)}
                </span>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
